
1- take words from textfile. DONE!
1- compare words one by one to a database of MyKnowledge. 
1- show all text again with marked unknown words. 
1- show unknows one by one to user, ask if he knows them or not
3-send the known ones to MyKnowledge
4- save the unknown ones to a StudyList


 TODO:
allow deleteing the last entry. decision == 'c' 
repeated vocabs should be ignored at entry.


