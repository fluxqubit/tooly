import db
import article
ar = article.Article('sample.txt')
ar.chop()       # ??? do I have to chop it first? can't that be done automatically as soon as I apply any of the next ones?
        
ar.get_words()
ar.get_sentences()
ar.get_paragraphs()
ar.sniffit()




