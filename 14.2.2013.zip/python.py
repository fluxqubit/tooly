class Trap:
        """ this is some class"""
        def __init__(self):
                self.setup()
        def setup(self):        # to feed info used in other methods
                self.points = (-1,-0.5,0,0.5,1)
                self.weights = (1,1,1,1,1)
        def eval(self, f):
                sum = 0.
                for i in range(len(self.points)):
                        sum += self.weights[i]*f(self.points[i])
                return sum

obj1 = Trap()
obj1.eval(lambda x:x**2)







class MyBase:
        def __init__(self, i, j):       # seems like __init__ has the initial values that you would feed into the class while creating an object. __init__ == A constructor
                                        # this can come later within the class. order should not be a problem.
                self.i = i;self.j=j     # i, j are instance attributes. we can access them as obj1.i, obj.j
        def write(self):
                print 'MyBase: i=', self.i, 'j=', self.j

obj1=MyBase(2,3)
obj1.write()


In a class, every method must have self at the first argument. BUT, it should not be written explicitely when the method is called.


SUBCLASSING,

class MySub(MyBase):
        def __init__(self,i,j,k):
                MyBase.__init__(self,i,j)
                self.k=k
        def write(self):
                print 'MySub: i=', self.i, 'j=', self.j, 'k=', self.k

-----------------------------

how return could add more stuff to the output

>>> def printme(s):
...     print s
...     return x
... 
>>> y=100
>>> printme(y)
100
10



import sqlite3 as lite

class DB:
        """ this is a database"""
        def __init__(self):
                self.setup()
        
        def setup(self):        # to feed info used in other methods
                self.points = (-1,-0.5,0,0.5,1)
                self.weights = (1,1,1,1,1)
        def eval(self, f):
                sum = 0.
                for i in range(len(self.points)):
                        sum += self.weights[i]*f(self.points[i])
                return sum

obj1 = Trap()
obj1.eval(lambda x:x**2)


conn=s3.connect('pythonsqlite.db')
c=conn.cursor()

c.execute("create table test (id integer, name text)")



conn.commit()
conn.close()

------------------------------------


